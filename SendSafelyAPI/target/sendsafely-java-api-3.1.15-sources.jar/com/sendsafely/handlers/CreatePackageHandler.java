package com.sendsafely.handlers;

import java.io.IOException;
import java.util.ArrayList;

import com.sendsafely.ContactGroup;
import com.sendsafely.File;
import com.sendsafely.Package;
import com.sendsafely.Recipient;
import com.sendsafely.dto.request.CreatePackageRequest;
import com.sendsafely.dto.response.CreatePackageResponse;
import com.sendsafely.enums.APIResponse;
import com.sendsafely.enums.Endpoint;
import com.sendsafely.exceptions.CreatePackageFailedException;
import com.sendsafely.exceptions.DeletePackageException;
import com.sendsafely.exceptions.LimitExceededException;
import com.sendsafely.exceptions.PackageInformationFailedException;
import com.sendsafely.exceptions.SendFailedException;
import com.sendsafely.exceptions.TokenGenerationFailedException;
import com.sendsafely.exceptions.UploadKeycodeException;
import com.sendsafely.upload.UploadManager;
import com.sendsafely.utils.CryptoUtil;

public class CreatePackageHandler extends BaseHandler 
{	
	
	private CreatePackageRequest request;
	private boolean isVDR = false;
	private String packageUserEmail = null;
	
	public CreatePackageHandler(UploadManager uploadManager) {
		super(uploadManager);
        request = new CreatePackageRequest(uploadManager.getJsonManager());
	}
	
	public void setVDR(boolean isVDR) {
		this.isVDR = isVDR;
	}
	
	public Package makeRequest(String email) throws CreatePackageFailedException, LimitExceededException {
		this.packageUserEmail = email;
		return makeRequest();
	}
	
	public Package makeRequest() throws CreatePackageFailedException, LimitExceededException {
		CreatePackageResponse response = send();
		
		if(response.getResponse() == APIResponse.SUCCESS) 
		{
			Package info = convert(response);

			if(this.isVDR)
			{
				syncWorkspaceKeycode(info);
			}

			return info;
		}
		else if(response.getResponse() == APIResponse.LIMIT_EXCEEDED)
		{
			throw new LimitExceededException(response.getMessage());
		}
		else
		{
			throw new CreatePackageFailedException(response.getMessage());
		}
	}
	
	protected CreatePackageResponse send() throws CreatePackageFailedException
	{
		this.request.setIsVDR(this.isVDR);
		this.request.setPackageUserEmail(this.packageUserEmail);

		try {
			return send(request, new CreatePackageResponse());
		} catch (SendFailedException e) {
			throw new CreatePackageFailedException(e);
		} catch (IOException e) {
			throw new CreatePackageFailedException(e);
		}
	}
	
	protected Package convert(CreatePackageResponse obj) throws CreatePackageFailedException
	{
		try
		{
			Package info = getPackageInformation(obj);
			info.setKeyCode(CryptoUtil.GenerateKeyCode());
			return info;
		}
		catch (TokenGenerationFailedException e)
		{
			throw new CreatePackageFailedException(e);
		}
	}
	
	protected void syncWorkspaceKeycode(Package info) throws CreatePackageFailedException
	{
		try {
			new KeycodeSyncHandler(uploadManager).syncPackageKeycode(info.getPackageId(), info.getKeyCode());
		} catch (UploadKeycodeException e) {
			if(deleteOrphanedWorkspace(info.getPackageId())) {
				throw new CreatePackageFailedException(e);
			}
			
			throw new CreatePackageFailedException(e.getMessage() + " (Workspace " + info.getPackageId()
					+ " could not be deleted and cannot be opened)", e);
		}
	}

	protected boolean deleteOrphanedWorkspace(String packageId)
	{
		try {
			new DeletePackageHandler(uploadManager).makeRequest(packageId);
			return true;
		} catch (DeletePackageException cleanupFailed) {
			// Swallowed so it cannot mask the upload error the caller needs to see.
			return false;
		}
	}

	protected Package getPackageInformation(CreatePackageResponse obj) throws CreatePackageFailedException
	{	
		Package info = new Package();
		try {
			info = ((PackageInformationHandler)(HandlerFactory.getInstance(uploadManager, Endpoint.PACKAGE_INFORMATION))).makeRequest(obj.getPackageId());
		} catch (PackageInformationFailedException e) {
			info.setPackageId(obj.getPackageId());
			info.setPackageCode(obj.getPackageCode());
			info.setServerSecret(obj.getServerSecret());
			info.setFiles(new ArrayList<File>());
			info.setRecipients(new ArrayList<Recipient>());
			info.setContactGroups(new ArrayList<ContactGroup>());
		}
		
		return info;
	}
	
}
