package com.sendsafely.upload;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;

import com.sendsafely.SendSafely;
import com.sendsafely.connection.ConnectionManager;
import com.sendsafely.credentials.CredentialsManager;
import com.sendsafely.enums.HTTPMethod;
import com.sendsafely.exceptions.CredentialsException;
import com.sendsafely.exceptions.SendFailedException;
import com.sendsafely.file.FileManager;
import com.sendsafely.json.JsonManager;
import com.sendsafely.utils.Progress;

public class S3UploadManager implements UploadManager {
	
	private final String CONTENT_TYPE = "application/octet-stream";
	private final String FILE_UPLOAD_CONTENT_TYPE = "multipart/form-data;";
	private final String CRLF = "\r\n";
	private final int BUFFER_SIZE = 1024;
	
	private CredentialsManager credentialsManager;
	private ConnectionManager conn;
    private JsonManager jsonManager;
	private InputStream content;
	private String responseVal = "";
	
	private String server;
	private String date;
	private int responseCode;
	private String responseMessage;
	private String responseContentType;
	private String etc;
	
	public S3UploadManager(ConnectionManager connManager, JsonManager jsonManager)
	{
		this.conn = connManager;
        this.jsonManager = jsonManager;
	}

	@Override
	public void send(String path, HTTPMethod method, String data) throws SendFailedException, IOException 
	{
		URL url = new URL(path);
		conn.open(url);
		this.date = conn.getHeader("Date");
		this.server = conn.getHeader("Server");
		this.responseCode = conn.getResponseCode();
		this.responseMessage = conn.getResponseMessage();
		this.responseContentType = conn.getContentType();
		this.content = conn.getResponse();
	}

	@Override
	public String sendFile(String path, FileManager file, String filename, String data, Progress progress) throws SendFailedException, IOException
	{
		URL url = createUrl(path);
		
		String boundary = Long.toHexString(System.currentTimeMillis());
		
		conn.open(url);
		
		addCredentials(data);
		
		// Set api key header.
		String contentType = FILE_UPLOAD_CONTENT_TYPE + " boundary=" + boundary;
		populateHeaders("POST", contentType);
		
		OutputStream output = conn.getOutputStream();
		
		PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, "UTF-8"), true); // true, autoflush
		
		setParam("requestData", data, boundary, writer);
		
		sendBinaryFile(filename, file.getInputStream(), output, writer, boundary, progress);
		
		// End of multipart/form-data.
		writer.append("--" + boundary + "--").append(CRLF);
		writer.flush();
	
		this.content = conn.getResponse();
		String responseVal = getResponse();		
		return responseVal;
	}
	

	
	@Override
	public String getResponse() throws IOException
	{
		// Wait for response
		BufferedReader in = new BufferedReader(new InputStreamReader(this.content));
		String responseVal = "";
		String line = null;
		while((line = in.readLine()) != null) 
		{
			responseVal += line;
		}
		
		return responseVal;
	}

    @Override
    public JsonManager getJsonManager() {
        return this.jsonManager;
    }
	
	@Override
	public String getContentType() {
		return conn.getHeader("Content-Type");
	}

	@Override
	public InputStream getStream() {
		return this.content;
	}
	
	
	@Override
	public String getServer() {
		return server;
	}
	@Override
	public String getDate() {
		return date;
	}
	@Override
	public int getResponseCode() {
		return responseCode;
	}
	@Override
	public String getResponseMessage() {
		return responseMessage;
	}
	
	public String getApiHost() {
		return conn.getHost();
	}
	
	private URL createUrl(String path) throws SendFailedException
	{
		try {
			return new URL(conn.getHost() + credentialsManager.getAPIPath() + path);
		} catch (MalformedURLException e) {
			throw new SendFailedException(e);
		}
	}
	
	private void sendBinaryFile(String filename, InputStream input, OutputStream output, PrintWriter writer, String boundary, Progress progress) throws IOException {
		
		writer.append("--" + boundary).append(CRLF);
		writer.append("Content-Disposition: form-data; name=\"textFile\"; filename=\"" + filename + "\"").append(CRLF);
		writer.append("Content-Type: text/plain; charset=UTF-8").append(CRLF);
		writer.append(CRLF).flush();
		
		try 
		{
			byte[] tmp = new byte[BUFFER_SIZE];
			int l;
			
			while ((l = input.read(tmp, 0, BUFFER_SIZE)) != -1) 
			{
				output.write(tmp, 0, l);
				progress.updateCurrent(l);
				output.flush();
			}
		} 
		finally 
		{
			if(input != null)
				input.close();
		}
		writer.append(CRLF).flush();
	}
	
	private void setParam(String key, String value, String boundary, PrintWriter writer) {
		writer.append("--" + boundary).append(CRLF);
		writer.append("content-disposition: form-data; name=\"" + key + "\"").append(CRLF);
		writer.append("content-type: text/plain; charset=UTF-8").append(CRLF);
		writer.append(CRLF);
		writer.append(value).append(CRLF).flush();
	}
	
	private void addCredentials(String data) throws SendFailedException {
		try {
			credentialsManager.addCredentials(conn, data);
		} catch (CredentialsException e) {
			throw new SendFailedException(e);
		}
	}
	
	private void populateHeaders(String method, String contentType) throws SendFailedException
	{
		conn.addHeader("Content-Type", contentType);
		conn.addHeader(SendSafely.SDK_VERSION_HEADER, SendSafely.SDK_VERSION_VALUE);
		if (SendSafely.CLIENT_VERSION != null) {
			conn.addHeader(SendSafely.CLIENT_VERSION_HEADER, SendSafely.CLIENT_VERSION);
		}
		conn.setRequestMethod(method);
	}

}
